package Exceptions;
/**
 * @author 8210311 Daniela Moreira
 * @author 8210367 Orlando Pires
 */
public class InvalidValue extends Throwable{
    public InvalidValue(String mensage){
        super(mensage);
    }
}
