package Player;
/**
 * @author 8210311 Daniela Moreira
 * @author 8210367 Orlando Pires
 */
/**
 * Equipas do jogo, Neutor caso não pertença a nenhuma equipa
 */
public enum Equipas {
    Sparks, Giants, Neutro
}
